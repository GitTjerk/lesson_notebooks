import pandas as pd
a = 3 + 5
b = input('Enter your name')
name = f'Your name is {b}'
print(name)

series = pd.Series([1, 2, 3, 4, 5])
print(series)